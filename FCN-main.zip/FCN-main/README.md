#### Instal On Termux
- pkg update [&&]() pkg upgrade -y
- pkg install python2 git -y
- rm -rf FCN
- git clone https://github.com/AngCyber/FCN
- pip install --upgrade pip
- pip2 install requests mechanize
- pip2 install futures bs4
- [cd]() FCN
- git pull
- python2 [face.py]()

### Thank You For Your Support

